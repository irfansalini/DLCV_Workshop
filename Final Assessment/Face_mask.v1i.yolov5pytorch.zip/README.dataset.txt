# Face_mask > 2022-08-01 3:48pm
https://universe.roboflow.com/object-detection/face_mask-g4xmd

Provided by Roboflow
License: CC BY 4.0

